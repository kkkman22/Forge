# Dependency Discipline — 详细规范

> 从 `skills/forge-build/SKILL.md §6.7` 拆分。SKILL 主文件只保留一行摘要指针。

添加新依赖前必须确认以下 4 项：

1. **现有技术栈是否已能解决**：优先使用标准库和项目已有工具
2. **依赖大小**：检查 bundle 影响（`npm pack --dry-run` 或等效命令）
3. **是否活跃维护**：检查最近 commit 时间、open issues 数量
4. **许可证兼容性**：必须与项目许可证兼容

## 规则

每个依赖都是负债。

- 不添加依赖是默认选择
- 添加依赖需要理由
