# Function Contracts

> No function call signatures currently defined in forge-build-light.
> Function contracts will be added as the TypeScript implementation evolves.
