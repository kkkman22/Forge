# Function Call Contracts (Detailed)

## loadAllAdrs

**Signature**: `loadAllAdrs(entries, readFile)` (from `src/adr-registry.ts`)

- **Parameters**:
  - `entries` — Array of ADR file paths enumerated from `.forge/decisions/ADR-NNNN-*.md`
  - `readFile` — Filesystem reader injected by the driver layer
- **Returns**: `AdrEntry[]` — parsed ADR frontmatter records
- **Purpose**: Load all existing ADRs before running Round 1 so perspective Subagents can reference prior decisions

---

## findRelatedAdrs

**Signature**: `findRelatedAdrs(taskDescription, adrs, limit)` (from `src/adr-registry.ts`)

- **Parameters**:
  - `taskDescription` — Current task description string
  - `adrs` — Output of `loadAllAdrs`
  - `limit` — Maximum number of related ADRs to return (default 5)
- **Returns**: `AdrEntry[]` ranked by Jaccard similarity
- **Purpose**: Surface the most relevant historical ADRs at Skill startup so the user can spot potential supersessions

---

## finalizeAdr

**Signature**: `finalizeAdr(input, readExistingFile)` (from `src/decide.ts`)

- **Parameters**:
  - `input` — `FinalizeAdrInput` containing title / topic / status / date / deciders / bodyMarkdown / existingAdrs / optional relatedAdrs & supersedes
  - `readExistingFile` — Filesystem reader for supersession updates
- **Returns**: `{ adrFilePath, adrFileContent, indexFilePath, indexContent, supersessionUpdates }`
- **Purpose**: Produce the ADR file, the idempotent index update, and any supersession rewrites in one call; the driver layer applies the writes

---

## checkDecideGlossaryConflicts

**Signature**: `checkDecideGlossaryConflicts(candidateTerms, glossary)` (from `src/decide.ts`)

- **Parameters**:
  - `candidateTerms` — New terms extracted from the user's decision proposal
  - `glossary` — Parsed `.forge/glossary.md` structure
- **Returns**: Conflict list (empty when no conflicts); each entry carries the existing definition and the candidate
- **Purpose**: Run before Round 1 kicks off; non-empty conflicts pause the Round and trigger `renderDecideGlossaryConflictPrompt`

---

## runCriteriaScreen

**Signature**: `runCriteriaScreen(decisions, signals)` (from `src/decide.ts`)

- **Parameters**:
  - `decisions` — Decision candidates emitted by the four perspectives
  - `signals` — Signal inputs (reversibility hints, explicit trade-off flags, etc.) gathered during Round 1
- **Returns**: Array of `AdrCriteriaResult` with `verdict` ∈ `WRITE_ADR | INLINE_NOTE | DISCARD`
- **Purpose**: Populate the `## ADR Criteria Check` section of the decision document before Round 2 Critic returns

---

## renderCriteriaCheck

**Signature**: `renderCriteriaCheck(result)` (from `src/adr-criteria.ts`)

- **Parameters**:
  - `result` — One `AdrCriteriaResult` item
- **Returns**: Four-line Markdown block with Reversibility / Surprising / Trade-off alternatives / Verdict
- **Purpose**: Deterministic rendering used inside `runCriteriaScreen` so the section stays auto-generated

---

## serializeSubagentSummary

**Signature**: `serializeSubagentSummary(summary)`

- **Parameters**:
  - `summary` — Perspective Subagent original return value (parsed as `SubagentSummary`)
- **Returns**: Summary string (≤200 tokens)
- **Purpose**: Round 1 视角输出完成后调用此函数生成摘要，Round 2 输入时使用摘要替代原始输出，控制 context 增长
